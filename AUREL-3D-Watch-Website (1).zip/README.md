# AUREL — Ultra Premium 3D Watch Website

A cinematic luxury-watch landing page built with React, Vite, TypeScript, Three.js and React Three Fiber.

## Run locally

1. Install Node.js (LTS).
2. Open this folder in Visual Studio Code.
3. Open Terminal → New Terminal.
4. Run:

```bash
npm install
npm run dev
```

5. Open the local URL printed by Vite (usually http://localhost:5173).

## Production build

```bash
npm run build
npm run preview
```

## Notes

- The hero watch is a procedural Three.js model built from geometry and physically based materials. It does not require a separately downloaded model file.
- The collection selector, navigation, responsive menu, scroll-linked hero movement, and contact enquiry interaction are implemented.
- The enquiry button currently opens a demo notice. Replace it with a real email/form backend before accepting customer enquiries.
- Google Fonts are loaded remotely; system fallbacks are provided.
