import { useFrame } from '@react-three/fiber'
import { useMemo, useRef } from 'react'
import * as THREE from 'three'
import type { MotionValue } from 'framer-motion'

type GearProps = { radius: number; teeth: number; color: string; speed?: number; position?: [number, number, number] }\n\nfunction Gear({ radius, teeth, color, speed = 0.2, position = [0, 0, 0] }: GearProps) {
  const ref = useRef<THREE.Group>(null)
  const toothGeometry = useMemo(() => new THREE.BoxGeometry(0.12, 0.19, 0.12), [])
  useFrame((_, delta) => { if (ref.current) ref.current.rotation.z += delta * speed })
  return <group ref={ref} position={position}>
    <mesh><cylinderGeometry args={[radius * .76, radius * .76, .08, 48]}/><meshStandardMaterial color={color} metalness={.9} roughness={.24}/></mesh>
    {Array.from({ length: teeth }).map((_, i) => <mesh key={i} geometry={toothGeometry} position={[Math.cos(i / teeth * Math.PI * 2) * radius, 0, Math.sin(i / teeth * Math.PI * 2) * radius]} rotation={[0, -i / teeth * Math.PI * 2, 0]}><meshStandardMaterial color={color} metalness={.9} roughness={.28}/></mesh>)}
    <mesh><torusGeometry args={[radius * .34, .035, 8, 32]}/><meshStandardMaterial color="#d9c39c" metalness={.9} roughness={.2}/></mesh>
    <mesh><cylinderGeometry args={[.08, .08, .12, 24]}/><meshStandardMaterial color="#17191a" metalness={.8} roughness={.2}/></mesh>
  </group>
}

export function Watch({ scrollRotation }: { scrollRotation: MotionValue<number> }) {
  const group = useRef<THREE.Group>(null)
  const strapMaterial = useMemo(() => new THREE.MeshStandardMaterial({ color: '#252a2c', metalness: .82, roughness: .27 }), [])
  const steel = useMemo(() => new THREE.MeshStandardMaterial({ color: '#b8bec0', metalness: .94, roughness: .19 }), [])
  const dark = useMemo(() => new THREE.MeshStandardMaterial({ color: '#101719', metalness: .72, roughness: .24 }), [])
  const gold = useMemo(() => new THREE.MeshStandardMaterial({ color: '#b99a64', metalness: .9, roughness: .2 }), [])
  const glass = useMemo(() => new THREE.MeshPhysicalMaterial({ color: '#d9e5e8', metalness: .12, roughness: .06, transmission: .24, transparent: true, opacity: .28, thickness: .18 }), [])
  const markers = Array.from({ length: 12 }, (_, i) => i)
  useFrame((state, delta) => {
    if (!group.current) return
    const target = scrollRotation.get()
    group.current.rotation.y = THREE.MathUtils.damp(group.current.rotation.y, target + (state.pointer.x * .22), 3.2, delta)
    group.current.rotation.x = THREE.MathUtils.damp(group.current.rotation.x, -0.16 + state.pointer.y * .13, 3, delta)
    group.current.position.y = Math.sin(state.clock.elapsedTime * .65) * .08
  })
  return <group ref={group} rotation={[ -.12, -.38, .12]} scale={1.22}>
    {/* upper and lower bracelet */}
    {Array.from({ length: 8 }).map((_, i) => <mesh key={`top-${i}`} position={[0, 1.35 + i * .19, 0]} scale={[.48 - i * .018, .18, .16]} material={strapMaterial}><boxGeometry args={[1, 1, 1]}/></mesh>)}
    {Array.from({ length: 8 }).map((_, i) => <mesh key={`bottom-${i}`} position={[0, -1.35 - i * .19, 0]} scale={[.48 - i * .018, .18, .16]} material={strapMaterial}><boxGeometry args={[1, 1, 1]}/></mesh>)}
    {/* case */}
    <mesh material={steel} scale={[1.18, 1.18, .34]}><cylinderGeometry args={[1, 1, .22, 96]}/></mesh>
    <mesh position={[0, 0, .11]} scale={[1.1, 1.1, .12]} material={gold}><cylinderGeometry args={[1, 1, .08, 96]}/></mesh>
    <mesh position={[0, 0, .17]} scale={[1.04, 1.04, .12]} material={dark}><cylinderGeometry args={[1, 1, .08, 96]}/></mesh>
    <mesh position={[0, 0, .235]} scale={[1.02, 1.02, .025]} material={glass}><cylinderGeometry args={[1, 1, .025, 96]}/></mesh>
    {/* dial minute track */}
    <mesh position={[0, 0, .245]}><ringGeometry args={[.91, .925, 96]}/><meshStandardMaterial color="#c6ad7e" metalness={.8} roughness={.3}/></mesh>
    {markers.map(i => <group key={i} rotation={[0, 0, -i * Math.PI / 6]} position={[0, 0, .26]}><mesh position={[0, .82, 0]} material={i % 3 === 0 ? gold : steel}><boxGeometry args={[.045, .12, .018]}/></mesh></group>)}
    {/* centre and hands */}
    <mesh position={[0, 0, .28]} rotation={[0, 0, -.55]} material={steel}><boxGeometry args={[.035, .56, .018]}/></mesh>
    <mesh position={[0, 0, .30]} rotation={[0, 0, .75]} material={gold}><boxGeometry args={[.025, .76, .02]}/></mesh>
    <mesh position={[0, 0, .32]} rotation={[0, 0, 1.8]} material={gold}><boxGeometry args={[.012, .88, .012]}/></mesh>
    <mesh position={[0, 0, .34]}><cylinderGeometry args={[.055, .055, .025, 24]}/><meshStandardMaterial color="#d2b783" metalness={.95}/></mesh>
    {/* crown */}
    <mesh position={[1.24, 0, 0]} rotation={[0, 0, Math.PI / 2]} material={gold}><cylinderGeometry args={[.13, .13, .28, 32]}/></mesh>
    {[-.12, .12].map((y) => <mesh key={y} position={[y < 0 ? -1.19 : 1.19, y, 0]} material={steel}><boxGeometry args={[.22, .28, .3]}/></mesh>)}
    {/* exhibition movement visible as a hint through rear edge */}
    <group position={[0, 0, -.22]} rotation={[Math.PI, 0, 0]}>
      <Gear radius={.34} teeth={12} color="#b79a69" speed={.45} position={[-.35, .28, -.04]}/>
      <Gear radius={.24} teeth={10} color="#aeb5b5" speed={-.6} position={[.34, -.28, -.05]}/>
    </group>
  </group>
}
