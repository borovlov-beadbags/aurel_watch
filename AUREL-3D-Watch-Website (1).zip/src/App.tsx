import { useEffect, useState } from 'react'
import { Canvas } from '@react-three/fiber'
import { Environment, ContactShadows } from '@react-three/drei'
import { motion, useScroll, useTransform } from 'framer-motion'
import { ArrowDown, ArrowUpRight, Menu, X, MoveUpRight } from 'lucide-react'
import { Watch } from './components/Watch'
import { useRef } from 'react'

const models = [
  { name: 'AUREL No. 01', type: 'AUTOMATIC / 41 MM', price: '$18,400', tone: 'steel', detail: 'A study in balance. Brushed steel, deep midnight enamel and a movement made to be admired.' },
  { name: 'AUREL No. 02', type: 'SKELETON / 40 MM', price: '$26,800', tone: 'gold', detail: 'An open architecture that reveals the quiet choreography of precision.' },
  { name: 'AUREL No. 03', type: 'CHRONOGRAPH / 42 MM', price: '$21,600', tone: 'black', detail: 'A confident instrument, shaped by purposeful geometry and considered detail.' },
]

function Header() {
  const [open, setOpen] = useState(false)
  return <header className="header">
    <a className="brand" href="#top">AUREL<span>®</span></a>
    <nav className={open ? 'nav nav-open' : 'nav'}>
      <a href="#collection" onClick={() => setOpen(false)}>COLLECTION</a>
      <a href="#craft" onClick={() => setOpen(false)}>OUR CRAFT</a>
      <a href="#atelier" onClick={() => setOpen(false)}>ATELIER</a>
    </nav>
    <a className="header-link" href="#collection">DISCOVER <MoveUpRight size={13}/></a>
    <button className="menu-button" onClick={() => setOpen(!open)} aria-label="Toggle menu">{open ? <X/> : <Menu/>}</button>
  </header>
}

function WatchStage() {
  const stageRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({ target: stageRef, offset: ['start start', 'end start'] })
  const rotate = useTransform(scrollYProgress, [0, 1], [0, Math.PI * 1.25])
  const y = useTransform(scrollYProgress, [0, 1], [0, 125])
  const scale = useTransform(scrollYProgress, [0, 1], [1, 0.82])
  return <section className="hero" id="top" ref={stageRef}>
    <div className="hero-meta"><span>INDEPENDENT WATCHMAKING</span><span>GENEVA · EST. 1984</span></div>
    <motion.div className="hero-copy" initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1, delay: .25 }}>
      <p className="eyebrow">THE ART OF PRECISION</p>
      <h1>Time, <em>refined.</em></h1>
      <p className="hero-description">An expression of quiet confidence.<br/>Designed to outlast the moment.</p>
      <a className="text-link" href="#collection">EXPLORE THE COLLECTION <ArrowUpRight size={15}/></a>
    </motion.div>
    <motion.div className="watch-stage" style={{ y, scale }}>
      <Canvas camera={{ position: [0, 0, 7.5], fov: 34 }} dpr={[1, 1.7]} gl={{ antialias: true, alpha: true }}>
        <ambientLight intensity={1.15}/>
        <directionalLight position={[5, 6, 5]} intensity={3.2}/>
        <pointLight position={[-4, 1, 2]} intensity={2.2} color="#c8a56b"/>
        <pointLight position={[2, -3, -3]} intensity={1.4} color="#dce5ef"/>
        <Watch scrollRotation={rotate}/>
        <Environment preset="studio"/>
        <ContactShadows position={[0, -2.35, 0]} opacity={0.25} scale={8} blur={2.8} far={4}/>
      </Canvas>
    </motion.div>
    <div className="hero-index"><span>01 / 04</span><span>THE SIGNATURE SERIES</span></div>
    <a className="scroll-cue" href="#manifesto"><span>SCROLL TO DISCOVER</span><ArrowDown size={14}/></a>
    <div className="hero-side-note">CRAFTED FOR THE UNREPEATABLE</div>
  </section>
}

function Manifesto() {
  return <section className="manifesto" id="manifesto">
    <div className="manifesto-top"><span>01 — THE PHILOSOPHY</span><span>BEYOND MEASUREMENT</span></div>
    <div className="manifesto-content">
      <p className="eyebrow">A DIFFERENT PERSPECTIVE ON TIME</p>
      <h2>Not made to<br/>follow time.<br/><em>Made to define it.</em></h2>
      <p className="manifesto-note">Every line has a reason. Every component has a purpose. AUREL brings considered design and mechanical artistry into a single, enduring object.</p>
    </div>
    <div className="manifesto-bottom"><span>DESIGN / ENGINEERING / LEGACY</span><span>01—1984</span></div>
  </section>
}

function Craft() {
  return <section className="craft" id="craft">
    <div className="craft-heading"><span className="eyebrow">02 — THE MECHANICS</span><span className="craft-number">01<span> / </span>03</span></div>
    <div className="craft-grid">
      <div className="craft-copy">
        <p className="eyebrow">THE MECHANICAL HEART</p>
        <h2>Precision<br/>in every<br/><em>movement.</em></h2>
        <p className="body-copy">A finely tuned automatic calibre, assembled with patience and finished by hand. A world of intricate motion, hidden beneath a calm exterior.</p>
        <a className="text-link light-link" href="#collection">DISCOVER THE MOVEMENT <ArrowUpRight size={15}/></a>
      </div>
      <div className="gear-art" aria-label="Abstract mechanical watch movement illustration">
        <div className="gear gear-one"><div/></div><div className="gear gear-two"><div/></div><div className="gear gear-three"><div/></div>
        <div className="gear-core">A<span>·</span></div>
        <div className="gear-caption">CALIBRE A-01 / 28,800 VPH</div>
      </div>
    </div>
    <div className="craft-footer"><span>ENGINEERED TO PERFECTION</span><span>EVERY SECOND MATTERS</span></div>
  </section>
}

function Materials() {
  const items = [
    ['01', 'SAPPHIRE CRYSTAL', 'Clarity without compromise. A protective surface with exceptional resistance.'],
    ['02', '316L STAINLESS STEEL', 'Sculpted, brushed and polished to create a distinctive play of light.'],
    ['03', 'AUTOMATIC CALIBRE', 'A self-winding mechanical heart, built for consistency and longevity.'],
  ]
  return <section className="materials" id="atelier">
    <div className="section-top"><span>03 — THE DETAILS</span><span>MATERIALS & FINISH</span></div>
    <div className="materials-intro"><p className="eyebrow">THE BEAUTY OF PURPOSE</p><h2>Every detail.<br/><em>Considered.</em></h2></div>
    <div className="material-list">{items.map(([n, title, desc]) => <div className="material-row" key={n}><span className="material-no">{n}</span><h3>{title}</h3><p>{desc}</p><ArrowUpRight size={17}/></div>)}</div>
  </section>
}

function Collection() {
  const [active, setActive] = useState(0)
  return <section className="collection" id="collection">
    <div className="section-top"><span>04 — THE COLLECTION</span><span>THREE EXPRESSIONS / ONE PHILOSOPHY</span></div>
    <div className="collection-head"><div><p className="eyebrow">THE SIGNATURE SERIES</p><h2>Find your<br/><em>own time.</em></h2></div><p className="collection-aside">Three distinct expressions of the AUREL philosophy. Each one, unmistakably its own.</p></div>
    <div className="product-layout">
      <div className={`product-visual ${models[active].tone}`}>
        <div className="product-halo"/>
        <div className="product-watch"><div className="product-strap top"/><div className="product-case"><div className="product-dial"><span className="dial-brand">AUREL</span><i className="hand hour"/><i className="hand minute"/><i className="hand second"/><b className="dial-pin"/></div></div><div className="product-strap bottom"/></div>
        <span className="product-edition">LIMITED SERIES / 001</span>
      </div>
      <div className="product-info">
        <span className="eyebrow">{models[active].type}</span>
        <h3>{models[active].name}</h3>
        <p>{models[active].detail}</p>
        <div className="product-price">{models[active].price}<span> / ENQUIRE FOR AVAILABILITY</span></div>
        <button className="outline-button" onClick={() => alert(`Thank you for your interest in ${models[active].name}. Please contact atelier@aurel.example to enquire.`)}>ENQUIRE <ArrowUpRight size={15}/></button>
        <div className="product-selector">{models.map((m, i) => <button key={m.name} className={active === i ? 'selector active' : 'selector'} onClick={() => setActive(i)}><span>0{i+1}</span>{m.name}<span className="selector-line"/></button>)}</div>
      </div>
    </div>
  </section>
}

function Footer() {
  return <footer className="footer">
    <div className="footer-main"><div><a className="brand footer-brand" href="#top">AUREL<span>®</span></a><p>TIME, REFINED.</p></div><div className="footer-cta"><span className="eyebrow">BEGIN A CONVERSATION</span><a href="mailto:atelier@aurel.example">The atelier <ArrowUpRight size={22}/></a></div></div>
    <div className="footer-bottom"><span>© 2026 AUREL WATCHMAKING</span><span>GENEVA · SWITZERLAND</span><a href="#top">BACK TO TOP ↑</a></div>
  </footer>
}

export default function App() {
  const [loading, setLoading] = useState(true)
  useEffect(() => { const timer = window.setTimeout(() => setLoading(false), 850); return () => window.clearTimeout(timer) }, [])
  return <>
    {loading && <motion.div className="loader" initial={{ opacity: 1 }} exit={{ opacity: 0 }} animate={{ opacity: 1 }}><span>AUREL</span><i/></motion.div>}
    <Header/>
    <main>
      <WatchStage/>
      <Manifesto/>
      <Craft/>
      <Materials/>
      <Collection/>
    </main>
    <Footer/>
    <div className="cursor-dot"/>
  </>
}
